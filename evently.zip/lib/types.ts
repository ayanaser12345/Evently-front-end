export interface Event {
  _id: string
  title: string
  description: string
  date: Date
  location: string
  privacy: "public" | "private"
  owner: string
  attendees: string[]
  rsvpRequests: string[]
  comments: Comment[]
  status: "active" | "completed" | "cancelled"
}

export interface Comment {
  _id: string
  user: string
  text: string
  createdAt: Date
}

export interface User {
  _id: string
  name: string
  email: string
  role: "user" | "admin"
}
