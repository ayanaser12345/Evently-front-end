import type { Event } from "./types"

// This would normally fetch from the backend API
// For now, we'll use mock data
export async function getEvents(): Promise<Event[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return [
    {
      _id: "1",
      title: "Game Night",
      description:
        "Join us for a fun evening of board games! We'll have classics like Monopoly and Scrabble, as well as modern favorites like Catan and Ticket to Ride.",
      date: new Date("2025-04-30T19:00:00Z"),
      location: "Online via Zoom",
      privacy: "public",
      owner: "mockUserId",
      attendees: [],
      rsvpRequests: [],
      comments: [],
      status: "active",
    },
    {
      _id: "2",
      title: "Study Group",
      description:
        "Collaborative study session for finals. We'll focus on computer science topics including algorithms, data structures, and system design.",
      date: new Date("2025-05-01T14:00:00Z"),
      location: "Library, Room 101",
      privacy: "public",
      owner: "mockUserId",
      attendees: [],
      rsvpRequests: [],
      comments: [],
      status: "active",
    },
    {
      _id: "3",
      title: "Book Club Meeting",
      description:
        'We\'ll be discussing "Project Hail Mary" by Andy Weir. Come prepared with your thoughts and questions!',
      date: new Date("2025-05-15T18:30:00Z"),
      location: "Coffee Shop Downtown",
      privacy: "public",
      owner: "mockUserId",
      attendees: [],
      rsvpRequests: [],
      comments: [],
      status: "active",
    },
    {
      _id: "4",
      title: "Hiking Trip",
      description:
        "A day hike at Sunset Mountain. The trail is moderate difficulty, about 5 miles round trip with beautiful views at the summit.",
      date: new Date("2025-05-22T09:00:00Z"),
      location: "Sunset Mountain Trailhead",
      privacy: "public",
      owner: "mockUserId",
      attendees: [],
      rsvpRequests: [],
      comments: [],
      status: "active",
    },
    {
      _id: "5",
      title: "Tech Meetup",
      description:
        'Monthly gathering of tech enthusiasts. This month\'s topic: "The Future of AI in Everyday Applications"',
      date: new Date("2025-05-10T17:00:00Z"),
      location: "Tech Hub Coworking Space",
      privacy: "public",
      owner: "mockUserId",
      attendees: [],
      rsvpRequests: [],
      comments: [],
      status: "active",
    },
    {
      _id: "6",
      title: "Cooking Class",
      description: "Learn to make authentic Italian pasta from scratch! All ingredients and tools will be provided.",
      date: new Date("2025-05-18T12:00:00Z"),
      location: "Community Kitchen",
      privacy: "public",
      owner: "mockUserId",
      attendees: [],
      rsvpRequests: [],
      comments: [],
      status: "active",
    },
  ]
}

export async function getEventById(id: string): Promise<Event | null> {
  const events = await getEvents()
  return events.find((event) => event._id === id) || null
}
