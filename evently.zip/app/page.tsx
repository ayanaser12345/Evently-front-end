import EventList from "@/components/event-list"
import { Suspense } from "react"
import EventListSkeleton from "@/components/event-list-skeleton"

export default function Home() {
  return (
    <main className="container mx-auto px-4 py-8">
      <section className="mb-12 text-center">
        <h1 className="text-4xl font-bold mb-4">Evently</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          A lightweight, community-focused platform for creating, managing, and attending small-scale events.
        </p>
      </section>

      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Upcoming Events</h2>
          <button className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-md">Create Event</button>
        </div>

        <Suspense fallback={<EventListSkeleton />}>
          <EventList />
        </Suspense>
      </section>
    </main>
  )
}
