export default function AboutPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">About Evently</h1>

        <div className="prose dark:prose-invert max-w-none">
          <p className="text-lg mb-6">
            Evently is a lightweight, community-focused web platform for creating, managing, and attending small-scale
            events like game nights, study groups, and online meetups.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">Our Mission</h2>
          <p>
            We believe that meaningful connections happen in small groups. While large event platforms focus on
            ticketing and monetization, Evently is designed specifically for micro-communities, emphasizing free RSVPs,
            pre-event discussions, and intuitive event management.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">Key Features</h2>
          <ul className="list-disc pl-6 space-y-2">
            <li>Simple event creation and management</li>
            <li>RSVP system with approval options</li>
            <li>Pre-event discussion for approved attendees</li>
            <li>Support for both in-person and virtual events</li>
            <li>Privacy controls for public and private events</li>
            <li>Timezone handling for global communities</li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8 mb-4">Get Started</h2>
          <p>
            Ready to organize your first event or join an existing one? Sign up for a free account today and start
            connecting with your community!
          </p>
        </div>
      </div>
    </main>
  )
}
