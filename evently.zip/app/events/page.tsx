import EventList from "@/components/event-list"
import { Suspense } from "react"
import EventListSkeleton from "@/components/event-list-skeleton"

export default function EventsPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">All Events</h1>
        <button className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-md">Create Event</button>
      </div>

      <Suspense fallback={<EventListSkeleton />}>
        <EventList />
      </Suspense>
    </main>
  )
}
