import { getEventById } from "@/lib/api"
import { formatDate, formatTime } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { CalendarIcon, MapPinIcon, Clock, Users } from "lucide-react"
import { notFound } from "next/navigation"

interface EventPageProps {
  params: {
    id: string
  }
}

export default async function EventPage({ params }: EventPageProps) {
  const event = await getEventById(params.id)

  if (!event) {
    notFound()
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">{event.title}</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Date</p>
              <p>{formatDate(event.date)}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Time</p>
              <p>{formatTime(event.date)}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <MapPinIcon className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Location</p>
              <p>{event.location}</p>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">About this event</h2>
          <p className="whitespace-pre-line">{event.description}</p>
        </div>

        <div className="bg-card rounded-lg p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Users className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-semibold">Attendees</h2>
          </div>

          {event.attendees.length > 0 ? (
            <ul className="space-y-2">
              {event.attendees.map((attendee) => (
                <li key={attendee} className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    {attendee[0].toUpperCase()}
                  </div>
                  <span>{attendee}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-muted-foreground">No attendees yet. Be the first to RSVP!</p>
          )}
        </div>

        <div className="flex justify-center">
          <Button size="lg" className="px-8">
            RSVP to Event
          </Button>
        </div>
      </div>
    </main>
  )
}
