"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CalendarIcon, MapPinIcon, Clock } from "lucide-react"
import { formatDate, formatTime } from "@/lib/utils"
import type { Event } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

interface EventCardProps {
  event: Event
}

export default function EventCard({ event }: EventCardProps) {
  const { toast } = useToast()

  const handleRSVP = () => {
    toast({
      title: "RSVP Requested",
      description: `You've requested to join "${event.title}". The organizer will review your request.`,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="line-clamp-1">{event.title}</CardTitle>
        <CardDescription className="flex items-center gap-1">
          <CalendarIcon className="h-4 w-4" />
          <span>{formatDate(event.date)}</span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground line-clamp-3 mb-4">{event.description}</p>
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span>{formatTime(event.date)}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPinIcon className="h-4 w-4 text-muted-foreground" />
            <span>{event.location}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" size="sm">
          View Details
        </Button>
        <Button size="sm" onClick={handleRSVP}>
          RSVP
        </Button>
      </CardFooter>
    </Card>
  )
}
