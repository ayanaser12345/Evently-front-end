"use client"

import Link from "next/link"
import { ModeToggle } from "./mode-toggle"
import { Button } from "./ui/button"
import { usePathname } from "next/navigation"

export default function Header() {
  const pathname = usePathname()

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-xl font-bold">
          Evently
        </Link>

        <nav className="hidden md:flex items-center space-x-6">
          <Link
            href="/"
            className={`${pathname === "/" ? "text-primary font-medium" : "text-foreground"} hover:text-primary transition-colors`}
          >
            Home
          </Link>
          <Link
            href="/events"
            className={`${pathname === "/events" ? "text-primary font-medium" : "text-foreground"} hover:text-primary transition-colors`}
          >
            Events
          </Link>
          <Link
            href="/about"
            className={`${pathname === "/about" ? "text-primary font-medium" : "text-foreground"} hover:text-primary transition-colors`}
          >
            About
          </Link>
        </nav>

        <div className="flex items-center space-x-4">
          <ModeToggle />
          <Button variant="outline">Sign In</Button>
        </div>
      </div>
    </header>
  )
}
