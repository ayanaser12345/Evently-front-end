const express = require("express")
const router = express.Router()
const Event = require("../models/Event")

// Get all events (public)
router.get("/", async (req, res) => {
  try {
    const events = await Event.find({ privacy: "public", status: "active" }).sort({ date: 1 })
    res.json(events)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

// Get single event by ID
router.get("/:id", async (req, res) => {
  try {
    const event = await Event.findById(req.params.id)
    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }
    res.json(event)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

// Create a new event
router.post("/", async (req, res) => {
  // In a real app, we would verify the user is authenticated here
  // For now, we'll use a mock user ID
  const mockUserId = "60d0fe4f5311236168a109ca"

  const event = new Event({
    title: req.body.title,
    description: req.body.description,
    date: req.body.date,
    location: req.body.location,
    privacy: req.body.privacy || "public",
    owner: mockUserId,
  })

  try {
    const newEvent = await event.save()
    res.status(201).json(newEvent)
  } catch (err) {
    res.status(400).json({ message: err.message })
  }
})

// Update an event
router.patch("/:id", async (req, res) => {
  try {
    // In a real app, we would verify the user is the owner or an admin
    const event = await Event.findById(req.params.id)
    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Update fields that are present in the request
    if (req.body.title) event.title = req.body.title
    if (req.body.description) event.description = req.body.description
    if (req.body.date) event.date = req.body.date
    if (req.body.location) event.location = req.body.location
    if (req.body.privacy) event.privacy = req.body.privacy
    if (req.body.status) event.status = req.body.status

    const updatedEvent = await event.save()
    res.json(updatedEvent)
  } catch (err) {
    res.status(400).json({ message: err.message })
  }
})

// Delete an event
router.delete("/:id", async (req, res) => {
  try {
    // In a real app, we would verify the user is the owner or an admin
    const event = await Event.findById(req.params.id)
    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    await Event.findByIdAndDelete(req.params.id)
    res.json({ message: "Event deleted" })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

// RSVP to an event
router.post("/:id/rsvp", async (req, res) => {
  try {
    // In a real app, we would get the user ID from the authenticated user
    const mockUserId = "60d0fe4f5311236168a109cb"

    const event = await Event.findById(req.params.id)
    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Check if user is already in attendees or rsvpRequests
    if (event.attendees.includes(mockUserId)) {
      return res.status(400).json({ message: "You are already attending this event" })
    }

    if (event.rsvpRequests.includes(mockUserId)) {
      return res.status(400).json({ message: "Your RSVP request is already pending" })
    }

    // Add user to rsvpRequests
    event.rsvpRequests.push(mockUserId)
    await event.save()

    res.json({ message: "RSVP request sent successfully" })
  } catch (err) {
    res.status(400).json({ message: err.message })
  }
})

module.exports = router
